var data = [];
window.onload = function () {
    var style = document.createElement("style");
    style.innerHTML = `
        p::selection {
            background: transparent;
            color: inherit;
        }
    `;
    var table = document.querySelectorAll("table");
    table.forEach((item) => {
        item.style.fontSize = "16px";
    });
    document.head.appendChild(style);
    document.addEventListener("contextmenu", (e) => e.stopPropagation(), true);
    document.addEventListener("keydown", (e) => e.stopPropagation(), true);

    const customButton = document.createElement("button");
    customButton.className = "custom-button";
    customButton.style.position = "absolute";
    customButton.style.border = "none";
    customButton.style.fontFamily = "Hevetica, Arial, sans-serif";
    customButton.style.fontSize = "16px";
    customButton.style.background = "white";

    document.body.appendChild(customButton);
    const questionMap = new Map();
    data.forEach((item) => {
        questionMap.set(item.question.toLowerCase(), item.answer);
        console.log(item);
    });
    document.addEventListener("selectionchange", function () {
        const selectedText = getSelectedText().toLowerCase();
        let answerFound = false;

        for (let [question, answer] of questionMap.entries()) {
            if (question.includes(selectedText)) {
                customButton.textContent = answer;
                answerFound = true;
                break;
            }
        }

        if (!answerFound) {
            customButton.textContent = "Không tồn tại đáp án trong cơ sở dữ liệu";
        }

        if (selectedText) {
            const selection = window.getSelection();
            if (selection.rangeCount > 0) {
                const range = selection.getRangeAt(0);
                const rect = range.getBoundingClientRect();

                customButton.style.left = 75 + "px";
                customButton.style.top = rect.top + window.scrollY + 30 + "px";
                customButton.style.display = "block";
            }
        } else {
            customButton.style.display = "none";
        }
    });

    var btnCauHoi = document.querySelectorAll("span[name='questionlabel']");
    btnCauHoi.forEach((btn) => {
        btn.addEventListener("click", function () {
            console.log("click");

            CheckAllQuest();
        });
    });

    function getSelectedText() {
        if (window.getSelection) {
            return window.getSelection().toString();
        } else if (document.selection && document.selection.type !== "Control") {
            return document.selection.createRange().text;
        }
        return "";
    }

    function trimAndReplace(str) {
        return str
            .trim()
            .replace(/\s+/g, " ")
            .replace(/<\/?p>|\\n|\?|:/g, "")
            .replace(/&nbsp;/g, "")
            .replace(/""/g, "");
    }

    function CheckAllQuest() {
        var quest = document.querySelectorAll('td[style="vertical-align: top; font-weight: bold"] p');
        if (quest.length == 0) {
            quest = document.querySelectorAll('td[style="vertical-align:top;font-weight:bold;"] p');
        }
        var choose = document.querySelectorAll("tr td span p");
        var inputCheck = document.querySelectorAll("tr td input[type='radio']");
        console.log(inputCheck);
        var questionDataAll = [];

        for (let i = 0; i < data.length; i++) {
            data[i].question = trimAndReplace(data[i].question);

            for (let p = 0; p < data[i].answer.length; p++) {
                data[i].answer[p] = trimAndReplace(data[i].answer[p]);
            }
        }

        for (let i = 0; i < quest.length; i++) {
            var onecauhoi = trimAndReplace(quest[i].innerText);
            var fourdapan = [];

            // Lấy 4 đáp án từ vị trí i * 4
            for (let j = 0; j < 4; j++) {
                fourdapan.push(trimAndReplace(choose[i * 4 + j].innerText));
            }

            //thoát vòng lặp khi chiều dài mảng đạt 60 câu
            if (questionDataAll.length > 59) break;
            questionDataAll.push({ question: onecauhoi, answer: fourdapan });
            // Kiểm tra xem câu hỏi có trong mảng data không
        }
        console.log(questionDataAll);

        for (let i = 0; i < quest.length; i++) {
            const matchedData = data.find((item) => item.question.includes(questionDataAll[i].question));

            if (matchedData) {
                const matchedAnswerIndex = questionDataAll[i].answer.findIndex((answer) => answer.includes(matchedData.answer));

                if (matchedAnswerIndex !== -1 && inputCheck[i * 4 + matchedAnswerIndex]) {
                    inputCheck[i * 4 + matchedAnswerIndex].checked = true;
                }
            }
        }
    }
};

data = [
    {
        question: "1. Nhà nước xã hội chủ nghĩa đầu tiên trên thế giới ra đời ở:",
        answer: "a. Liên Xô cũ",
    },
    {
        question: "2. Nhà nước xã hội chủ nghĩa Việt Nam ra đời sau:",
        answer: "a. Cách mạng tháng 8/1945",
    },
    {
        question: "3. Bản chất của nhà nước Cộng hoà XHCN Việt Nam:",
        answer: "a. Là nhà nước dân chủ, của dân, do dân và vì dân",
    },
    {
        question: "4. Hiến pháp là văn bản pháp lý có đặc điểm nào sau đây?",
        answer: "d. Tất cả đều đúng",
    },
    {
        question: "5. Nguyên tắc hoạt động của bộ máy nhà nước cộng hòa xã hội chủ nghĩa Việt Nam là:",
        answer: "a. Đặt dưới sự lãnh đạo của Đảng cộng sản, Tất cả quyền lực nhà nước đều thuộc về nhân dân, nhân dân tham gia đông đảo vào quản lý nhà nước, thực hiện tập trung dân chủ và tăng cường pháp chế",
    },
    {
        question: "6. Đặt dưới sự lãnh đạo của Đảng cộng sản Việt Nam, là một nguyên tắc hoạt động của:",
        answer: "c. Bộ máy nhà nước xã hội chủ nghĩa Việt Nam",
    },
    {
        question: "7. Nguyên thủ quốc gia của nước CHXHCN Việt Nam là:",
        answer: "b. Chủ tịch nước",
    },
    {
        question: "8. Đặt ra thuế và thu thuế là:",
        answer: "d. Một trong những đặc trưng cơ bản của Nhà nước",
    },
    {
        question: "9. Đặt ra pháp luật và buộc mọi thành viên trong xã hội phải thực hiện, đó là đặc trưng của:",
        answer: "d. Mọi nhà nước",
    },
    {
        question: "10. Với tư cách là cơ quan quyền lực nhà nước cao nhất, Quốc hội thực hiện chức năng cơ bản nào sau đây?",
        answer: "a. Chức năng lập pháp",
    },
    {
        question: "11. Nhà nước không tồn tại trong xã hội nào sau đây?",
        answer: "c. Xã hội Cộng sản nguyên thủy",
    },
    {
        question: "12. Theo quan điểm của chủ nghĩa Mác – Lênin, nguyên nhân chủ yếu làm xuất hiện Nhà nước là:",
        answer: "c. Do xã hội có sự phân chia giai cấp và đấu tranh giai cấp",
    },
    {
        question: "13. Bản chất giai cấp của Nhà nước thể hiện:",
        answer: "a. Nhà nước là một bộ máy trấn áp đặc biệt của giai cấp này đối với giai cấp khác",
    },
    {
        question: "14. Bản chất xã hội của Nhà nước thể hiện:",
        answer: "d. Nhà nước là bộ máy nhằm bảo đảm trật tự an toàn xã hội và đảm đương các công việc chung vì sự phát triển của xã hội",
    },
    {
        question: "15. Dấu hiệu nào sau đây không phải là đặc trưng cơ bản của Nhà nước?",
        answer: "c. Nhà nước điều chỉnh xã hội bằng các tập quán và đạo đức xã hội",
    },
    {
        question: "16. Chức năng chính của Nhà nước gồm các loại chức năng sau:",
        answer: "b. Các chức năng đối nội và các chức năng đối ngoại",
    },
    {
        question: "17. Hình thức chính thể của Nhà nước Cộng hòa xã hội chủ nghĩa Việt Nam hiện nay là:",
        answer: "c. Cộng hòa dân chủ",
    },
    {
        question: "18. Kiểu Nhà nước đầu tiên trong lịch sử là:",
        answer: "c. Nhà nước Chiếm hữu nô lệ",
    },
    {
        question: "19. Chủ tịch nước của nước Cộng Hoà xã hội chủ nghĩa Việt Nam theo Hiến pháp 2013 có quyền:",
        answer: "c.  Thay mặt Nhà nước để quyết định mọi vấn đề đối nội và đối ngoại",
    },
    {
        question: "20. Hội đồng nhân dân các cấp là:",
        answer: "b. Cơ quan quyền lực Nhà nước ở địa phương",
    },
    {
        question: '21. "Quyền lực của nhà nước về bản chất giống quyền lực của người đứng đầu trong gia đình" là quan điểm của học thuyết nào?',
        answer: "b. Thuyết gia trưởng",
    },
    {
        question: '22. "Nhà nước là sự ký kết hợp tác của mọi thành viên trong xã hội sống trong trạng thái tự nhiên của con người" là quan điểm của học thuyết nào?',
        answer: "c. Thuyết khế ước",
    },
    {
        question: '23. "Nhà nước là sự phát triển của gia đình và quyền gia trưởng" là quan điểm của học thuyết nào?',
        answer: "b. Thuyết gia trưởng",
    },
    {
        question: "24. Hội đồng nhân dân chịu trách nhiệm trước:",
        answer: "c. Cơ quan quyền lực cấp trên và nhân dân địa phương",
    },
    {
        question: "25. Ủy ban nhân dân chịu trách nhiệm trước:",
        answer: "d. Hội đồng nhân dân cùng cấp",
    },
    {
        question: "26. Đảng cộng sản Việt Nam là một:",
        answer: "a. Tổ chức chính trị",
    },
    {
        question: "27. Cơ quan nào sau đây không được quyền ban hành nghị quyết?",
        answer: "d. Bộ",
    },
    {
        question: "28. Ủy ban nhân dân phường Trảng Dài do:",
        answer: "b. Hội đồng Nhân dân phường Trảng Dài bầu ra",
    },
    {
        question: "29. Hội đồng nhân dân huyện Định Quán chịu trách nhiệm trước:",
        answer: "d. Cả a và b",
    },
    {
        question: "30. Ủy ban nhân dân tỉnh Đồng Nai chịu trách nhiệm trước:",
        answer: "d. Hội đồng nhân dân tỉnh Đồng Nai",
    },
    {
        question: "31. Quyền lực công của Nhà nước khác với quyền lực công trong xã hội cộng sản nguyên thủy ở những điểm nào?",
        answer: "d. Tất cả đều đúng",
    },
    {
        question: '32. "Nửa nhà nước" là khái niệm chỉ kiểu nhà nước nào?',
        answer: "d. Xã hội chủ nghĩa",
    },
    {
        question: "33. Theo quan điểm Mác - Lenin, nguồn gốc ra đời của nhà nước là?",
        answer: "a. Do xuất hiện chế độ tư hữu và phân chia giai cấp, mâu thuẫn giai cấp",
    },
    {
        question: "34. Nhà nước Việt Nam ra đời trên cơ sở nào?",
        answer: "d. Là kết quả đấu tranh và thắng lợi của Cách mạng Tháng Tám năm 1945",
    },
    {
        question: "35. Bản hiến pháp Hiện hành của Việt Nam là hiến pháp năm nào?",
        answer: "c. 2013",
    },
    {
        question: "36. Hiến pháp bên cạnh mang tính pháp lý còn thể hiện:",
        answer: "d. Tính chính trị",
    },
    {
        question: "37. Quốc hội chịu trách nhiệm trước:",
        answer: "a. Nhân dân",
    },
    {
        question: "38. Chức năng của chính phủ:",
        answer: "a. Thống nhất quản lý các vấn đề thuộc mọi lĩnh vực đời sống xã hội",
    },
    {
        question: "39. Ngân hàng nhà nước Việt Nam:",
        answer: "b. Là cơ quan ngang bộ",
    },
    {
        question: "40. Thanh tra chính phủ là:",
        answer: "b. Là cơ quan ngang bộ",
    },
    {
        question: "41. Theo quan điểm của chủ nghĩa Mác – Lenin, nhà nước sẽ bị mất đi ở xã hội nào?",
        answer: "c. Cộng sản chủ nghĩa",
    },
    {
        question: "42. Hiến pháp là văn bản pháp lý có đặc điểm nào sau đây?",
        answer: "a. Có hiệu lực cao nhất trong hệ thống văn bản quy phạm pháp luật",
    },
    {
        question: "43. Theo quan điểm của thuyết thần học, thì ai là người sinh ra nhà nước?",
        answer: "b. Thần thánh",
    },
    {
        question: "44. Theo quan điểm của chủ nghĩa Mác – Lenin, nguồn gốc trực tiếp làm cho nhà nước ra đời, đó là?",
        answer: "a. Đấu tranh giai cấp",
    },
    {
        question: "45. Theo quan điểm của thuyết bạo lực, nhà nước ra đời là do?",
        answer: "d. Do kết quả của các cuộc chiến tranh",
    },
    {
        question: "46. Con người đã trải qua những hình thức cộng đồng người nào?",
        answer: "d. Thị tộc – bộ",
    },
    {
        question: "48. Trong các cộng đồng người ở các làng xã của Việt Nam thời phong kiến, người ta quản lý xã hội bằng biện pháp chính nào sau đây?",
        answer: "c. Lệ làng",
    },
    {
        question: "49. Học thuyết nào sau đây đề cao vai trò giáo dục đạo đức cá nhân, đặc biệt đối với người quân tử?",
        answer: "b. Nho giáo",
    },
    {
        question: "50 . Ai là người có quyền lực cao nhất trong bộ máy chính quyền theo quan điểm của Nho giáo?",
        answer: "b. Thiên Tử",
    },
    {
        question: "51. Nguyên nhân sâu xa dẫn đến sự ra đời của Nhà nước theo quan điểm của Chủ nghĩa Mác – Lenin, đó là?",
        answer: "b. Sự xuất hiện tư hữu",
    },
    {
        question: "52. Theo quan điểm Nho giáo, xã hội tồn tại các mối quan hệ giường cột nào sau đây?",
        answer: "d. Vua tôi; cha con; vợ chồng; anh em; bạn bè",
    },
    {
        question: "53. Nhà nước có những chức năng nào sau đây?",
        answer: "d. Các đáp án trên đều đúng",
    },
    {
        question: "54. Có bao nhiêu chế độ xã hội có sự tồn tại của nhà nước?",
        answer: "b. 4",
    },
    {
        question: "55. Nhận định nào sau đây là đúng nhất?",
        answer: "a. Nhà nước ra đời nhằm mục đích trấn áp giai",
    },
    {
        question: "56. Kiểu nhà nước là khái niệm dùng để chỉ?",
        answer: "c. Giai cấp nào thống trị trong xã hội",
    },
    {
        question: "57. Khái niệm “hình thức nhà nước” dùng để diễn tả những vấn đề nào sau đây?",
        answer: "d. Tất cả các vấn đề trên",
    },
    {
        question: "58. Bản chất của việc sử dụng các phương pháp cai trị xã hội như thế nào là nội hàm của khái niệm nào sau đây?",
        answer: "b. Chế độ chính trị",
    },
    {
        question: "59. Tam quyền phân lập là tư tưởng về?",
        answer: "d. Tất cả các đáp án trên",
    },
    {
        question: "60. Trong chế độ phong kiến, hình thức chỉnh thể nhà nước là?",
        answer: "b. Hình thức chỉnh thể quân chủ tuyệt",
    },
    {
        question: "Pháp luật xã hội chủ nghĩa là do:",
        answer: "b. Do nhà nước xã hội chủ nghĩa ban hành",
    },
    {
        question: "2. Pháp luật có vai trò quan trọng đối với kinh tế, thể hiện ở việc:",
        answer: "d. Tất cả đều đúng",
    },
    {
        question: "3. Pháp luật có vai trò đối với xã hội, bởi lẽ:",
        answer: "d. Tất cả đều đúng",
    },
    {
        question: "4. Pháp luật không tồn tại trong xã hội nào sau đây?",
        answer: "d. Tất cả đều đúng",
    },
    {
        question: "5. Văn bản quy phạm pháp luật là văn bản do:",
        answer: "d. Cơ quan Nhà nước có thẩm quyền ban hành",
    },
    {
        question: "6. Luật Giáo dục do cơ quan nào ban hành?",
        answer: "b. Quốc hội",
    },
    {
        question: "7. Xét ở khía cạnh trình độ, ý thức pháp luật được chia thành hai loại:",
        answer: "a. ý thức pháp luật thông thường và ý thức pháp luật mang tính lý luận",
    },
    {
        question: "8. Pháp luật Việt Nam chưa từng sử dụng hình thức pháp luật nào sau đây:",
        answer: "b. Tiền lệ pháp",
    },
    {
        question: "9. Chức năng của pháp luật:",
        answer: "d. Tất cả đều đúng",
    },
    {
        question: "10. Pháp luật được xem là?",
        answer: "a. Những quy tắc ứng xử, xử sự chung của một quốc gia",
    },
    {
        question: "11. Nguồn của Pháp luật có thể là:",
        answer: "d. Tất cả đều đúng",
    },
    {
        question: "12. Pháp luật thể hiện ý chí của giai cấp nào sau đây?",
        answer: "b. Giai cấp thống trị",
    },
    {
        question: "13. Lực lượng nào sau đây sẽ đảm bảo Pháp luật được thực hiện?",
        answer: "a. Nhà nước",
    },
    {
        question: "14. Xét về mặt khách quan, Pháp luật ra đời là do?",
        answer: "a. Chế độ tư hữu và đấu tranh giai cấp, cùng với sự ra đời của nhà nước",
    },
    {
        question: "15. Về mặt chủ quan, Pháp luật là do?",
        answer: "b. Nhà nước ban hành hoặc thừa nhận pháp luật",
    },
    {
        question: "16. Tính cưỡng chế của Pháp luật khác với ý thức đạo đức, tôn giáo ở chỗ:",
        answer: "d. Tất cả các đáp án trên",
    },
    {
        question: "17. Pháp luật chỉ cách ứng xử mà mọi người phải tuân theo trong những trường hợp nhất định, là tính chất nào sau đây của Pháp luật?",
        answer: "b. Tính phổ biến",
    },
    {
        question: "18. Văn bản pháp luật cấp dưới không được trái với văn bản cấp trên, là tính chất nào sau đây của Pháp luật?",
        answer: "d. Tính xác định chặt chẽ về hình thức",
    },
    {
        question: "19. Pháp luật có những chức năng cơ bản nào sau đây?",
        answer: "d. Tất cả đều đúng",
    },
    {
        question: "20. Giữa pháp luật và kinh tế, thì:",
        answer: "a. Kinh tế quyết định đến pháp luật",
    },
    {
        question: "21. Phương pháp điều chỉnh hành vi con người của Pháp luật và đạo đức, khác nhau ở chỗ:",
        answer: "a. Pháp luật điều chỉnh bằng tính cưỡng chế, đạo đức bằng ý thức tự giác",
    },
    {
        question: "22. Chế tài xét sử của Pháp luật và đạo đức khác nhau ở chỗ:",
        answer: "d. Tất cả đều đúng",
    },
    {
        question: "23. Để quản lý xã hội, thời kỳ phong kiến Trung Quốc đã sử dụng học thuyết nào sau đây là chủ yếu?",
        answer: "b. Nho giáo",
    },
    {
        question: "24. Đặc điểm chung trong việc quản lý xã hội của các học thuyết Nho giáo, Đạo giáo, Phật giáo lấy yếu tố nào làm nòng cốt?",
        answer: "a. Nhân nghĩa",
    },
    {
        question: '25. Vì sao nói "Đạo đức là pháp luật tối đa, pháp luật là đạo đức tối thiểu"?',
        answer: "d. Tất cả đều đúng",
    },
    {
        question: "26. Pháp luật không có ở chế độ nào sau đây?",
        answer: "a. Cộng sản nguyên thủy",
    },
    {
        question: "27. Bản chất của Pháp luật là?",
        answer: "b. Biểu hiện ý chí của giai cấp thống trị",
    },
    {
        question: "28. Chức năng nào KHÔNG phải là chức năng của pháp luật:",
        answer: "b. Chức năng xây dựng và bảo vệ tổ quốc",
    },
    {
        question: "29. Các thuộc tính của pháp luật là:",
        answer: "c. Tính bắt buộc chung (hay tính quy phạm phổ biến); Tính xác định chặt chẽ về mặt hình thức",
    },
    {
        question: "30. Theo quan điểm của chủ nghĩa Mác – Lênin, nhà nước và pháp luật là hai hiện tượng xã hội:",
        answer: "a. Cùng phát sinh, phát triển, cùng tồn tại và tiêu vong.",
    },
    {
        question: "31. Thuộc tính (đặc trưng) nào sau đây là của pháp luật:",
        answer: "c. Tính xác định chặt chẽ về mặt hình thức; Tính bắt buộc chung (tính quy phạm phổ biến",
    },
    {
        question: "32. Thuộc tính (đặc trưng) nào sau đây là của pháp luật:",
        answer: "c. Tính được đảm bảo thực hiện bằng nhà nước; Tính bắt buộc chung (tính quy phạm phổ biến)",
    },
    {
        question: "33. Thuộc tính (đặc trưng) nào sau đây là của pháp luật:",
        answer: "c. Tính được đảm bảo thực hiện bằng nhà nước; Tính xác định chặt chẽ về mặt hình thức",
    },
    {
        question: "34. Thuộc tính (đặc trưng) nào sau đây là của pháp luật:",
        answer: "a. Tính xác định chặt chẽ về mặt hình thức",
    },
    {
        question: "35. Thuộc tính (đặc trưng) nào sau đây là của pháp luật:",
        answer: "a. Tính bắt buộc chung (tính quy phạm phổ biến)",
    },
    {
        question: "36. Thuộc tính (đặc trưng) nào sau đây là của pháp luật:",
        answer: "b. Tính được đảm bảo thực hiện bằng nhà nước",
    },
    {
        question: "39. Pháp luật là quy tắc xử sự chung, được áp dụng đối với tất cả mọi người là thể hiện đặc trưng nào dưới đây của pháp luật?",
        answer: "a. Tính quy phạm phổ biến.",
    },
    {
        question: "41. Pháp luật không quy định về những việc nào dưới đây ?",
        answer: "a. Nên làm",
    },
    {
        question: "43. Để quản lí xã hội, Nhà nước cần sử dụng phương tiện quan trọng nhất nào dưới đây?",
        answer: "a. Pháp luật",
    },
    {
        question: "44. Nội dung của tất cả các văn bản pháp luật đều phải phù hợp, không được trái với Hiến pháp là thể hiện đặc trưng nào dưới đây của pháp luật?",
        answer: "a. Tính xác định chặt chẽ về mặt hình thức.",
    },
    {
        question: "45. Các quy phạm pháp luật do Nhà nước ban hành phù hợp với lợi ích của giai cấp cầm quyền là thể hiện bản chất nào dưới đây của phâp luật?",
        answer: "b.  Bản chất giai cấp.",
    },
    {
        question: "47. Pháp luật phản ánh những nhu cầu, lợi ích của giai cấp, tầng lớp khác nhau trong xã hội là thể hiện bản chất nào dưới đây của pháp luật?",
        answer: "a. Bản chất xã hội.",
    },
    {
        question:
            "48. Luật Hôn nhân và gia đình năm 2014 quy định nam, nữ khi kết hôn với nhau phải tuân theo điều kiện: “Việc kết hôn phải được đăng kí và do cơ quan nhà nước có thẩm quyền thực hiện”, là thể hiện đặc trưng nào dưới đây của pháp luật ?",
        answer: "b. Tính quy phạm phổ biến.",
    },
    {
        question: "50. Pháp luật có vái trò như thế nào đối với công dân ?",
        answer: "b. Bảo vệ quyền và lợi ích hợp pháp của công dân.",
    },
    {
        question: "1. Văn bản quy phạm pháp luật có hiệu lực cao nhất, các văn bản quy phạm pháp luật khác không được trái với nó, đó chính là:",
        answer: "c. Hiến pháp",
    },
    {
        question: "2. Điểm nào sau đây không phải là điểm khác nhau giữa tập quán và tập quán pháp?",
        answer: "d. Tất cả đều sai",
    },
    {
        question: "3. Pháp lệnh do ai hoặc cơ quan nào ban hành?",
        answer: "d. Ủy ban thường vụ Quốc hội",
    },
    {
        question: "4. Chỉ thị do ai hoặc cơ quan nào ban hành?",
        answer: "a. Ủy ban nhân dân",
    },
    {
        question: "5. Hiến pháp 2013 có hiệu lực thi hành từ ngày nào?",
        answer: "b. 01/01/2014",
    },
    {
        question: "6. Khái niệm “Hình thức pháp luật” dùng để chỉ:",
        answer: "b. Những dạng tồn tại thực tế của pháp luật",
    },
    {
        question: "7. Hình thức pháp luật là hoạt động nào sau đây:",
        answer: "d. Hợp pháp hóa trong các hoạt động làm luật và ban hành pháp luật",
    },
    {
        question: "8. Trong hoạt động xét xử của tòa án, Tòa án sẽ sử dụng hình thức pháp luật chính nào sau đây?",
        answer: "d. Văn bản quy phạm pháp luật",
    },
    {
        question: "9. Cơ sở để hình thành các Công ước quốc tế là?",
        answer: "b. Tất cả các quốc gia đều có mối quan hệ với nhau từ song phương tới đa phương",
    },
    {
        question: "10. Tòa án chỉ sử dụng các công ước quốc tế khi:",
        answer: "a. Quốc gia đó đã ký kết tuân thủ các Công ước trên phạm vi lãnh thổ của mình",
    },
    {
        question: "11. Ban hành pháp luật thành văn bản, do cơ quan nhà nước có thẩm quyền ban hành là đặc điểm của hình thức pháp luật nào sau đây?",
        answer: "d. Văn bản quy phạm pháp luật",
    },
    {
        question: "12. Hình thức pháp luật nào hiện nay được coi là hình thức pháp luật chủ yếu của mọi nhà nước, và được các Tòa án áp dụng trong công tác xét xử?",
        answer: "d. Văn bản quy phạm pháp luật",
    },
    {
        question: "13. Ở Việt Nam, hình thức pháp luật nào được xem là phương tiện quan trọng để thể hiện đường lối, chính sách của Đảng Cộng sản Việt Nam?",
        answer: "d. Văn bản quy phạm pháp luật",
    },
    {
        question: "14. Yếu tố nào sau đây được xem là linh hồn của các văn bản quy phạm pháp luật ở Việt Nam hiện nay?",
        answer: "b. Đường lối, chính sách của Đảng Cộng sản Việt Nam",
    },
    {
        question: "15. Sự khác nhau giữa tập quán và tập quán pháp thể hiện ở chỗ?",
        answer: "d. Tất cả đều đúng",
    },
    {
        question: "16. Ở Việt Nam những ngày như Tết nguyên đán, ngày rằm, các lễ hội được xem là?",
        answer: "c. Tập quán",
    },
    {
        question: "17. Khái niệm “Tập quán pháp” dùng để chỉ:",
        answer: "b. Những thói quen được hình thành từ đời sống làm khuôn mẫu điều chỉnh hành vi của con người",
    },
    {
        question: "18. Dân tộc Thái cấm phụ nữ vào gian thờ cúng tổ tiên là ví dụ về?",
        answer: "c. Tập quán pháp",
    },
    {
        question: "19. Hạn chế của tập quán pháp là?",
        answer: "a. Đặc trưng của địa phương, khó áp dụng cho địa phương khác",
    },
    {
        question:
            "20. Hình thức áp dụng cách giải quyết các vụ kiện dựa theo những vụ kiện chưa được nêu trong văn bản pháp luật, song đã từng giải quyết vụ kiện tương tự, hình thức pháp luật đó là?",
        answer: "b. Tiền lệ pháp",
    },
    {
        question: "21. Điểm khác biệt giữa văn bản thường và văn bản quy phạm pháp luật thể hiện ở chỗ?",
        answer: "d. Tất cả các đáp án trên.",
    },
    {
        question: "22. Quốc hội được phép ban hành văn bản nào sau đây?",
        answer: "a. Hiến Pháp, luật, nghị quyết Quốc hội,",
    },
    {
        question: "23. Chủ tịch nước được phép ban hành văn bản pháp luật nào sau đây?",
        answer: "b. Lệnh, nghị quyết",
    },
    {
        question: "24. Chính phủ được phép ban hành văn bản pháp luật nào sau đây?",
        answer: "c. Nghị định",
    },
    {
        question: "25. Thủ tướng chính phủ được phép ban hành văn bản pháp luật nào sau đây?",
        answer: "d. Quyết định",
    },
    {
        question: "26. Văn bản luật là những văn bản nào sau đây?",
        answer: "d. Tất cả các đáp án trên",
    },
    {
        question: "27. Văn bản nào là văn bản dưới luật trong những văn bản dưới đây?",
        answer: "d. Lệnh, Nghị quyết của Chủ tịch nước",
    },
    {
        question: "28. Văn bản pháp luật nào được xem là “đạo luật mẹ” trong hệ thống văn bản pháp luật Việt Nam hiện nay?",
        answer: "a. Hiến Pháp",
    },
    {
        question: "29. Văn bản hướng dẫn thực hiện Hiến pháp và Pháp luật được gọi là?",
        answer: "d. Nghị định",
    },
    {
        question:
            "30. Trong một số trường hợp, Nghị định hướng dẫn thi hành luật cũng chưa áp dụng được thực tiễn nên cần đến loại văn bản luật Hướng dẫn thi hành Nghị định do các Bộ thuộc Chính phủ ban hành, văn bản đó gọi là gì?",
        answer: "d. Thông Tư hướng dẫn thi hành Nghị định",
    },
    {
        question: "31. Nhận định nào sau đây là KHÔNG chính xác?",
        answer: "a. Pháp luật chỉ có thể được hình thành bằng con đường ban hành của nhà nước.",
    },
    {
        question: "33. Khẳng định nào sau đây là đúng:",
        answer: "c. Tập quán pháp là tập quán có thể được nhà nước thừa nhận hoặc không cần phải được nhà nước thừa nhận; Tập quán pháp là tập quán được nhà nước thừa nhận",
    },
    {
        question: "1. Quy phạm pháp luật là:",
        answer: "a. Quy tắc xử sự có tính bắt buộc chung do nhà nước ban hành và bảo đảm thực hiện",
    },
    {
        question: "2. Quy phạm pháp luật là quy tắc xử sự cho phép cá nhân:",
        answer: "b, Chỉ được làm những việc mà luật cho phép và không cấm",
    },
    {
        question: "3. Bộ phận nào của Quy phạm pháp luật nêu lên cách thức xử sự của chủ thể?",
        answer: "b. Quy định",
    },
    {
        question: "4. Tế bào nhỏ nhất trong hệ thống pháp luật là?",
        answer: "c. Quy phạm pháp luật",
    },
    {
        question: "5. Quy phạm xã hội được hiểu là?",
        answer: "b. Quy tắc ứng xử của con người trong cuộc sống",
    },
    {
        question: "6. Những quy tắc nào điều chỉnh các mối quan hệ xã hội của con người?",
        answer: "d. Tất cả các đáp án trên",
    },
    {
        question: "7. Quy phạm pháp luật được hiểu là?",
        answer: "d. Tất cả các phương án trên",
    },
    {
        question: "8. Những quy tắc hành vi được hình thành trong xã hội trên cơ sở quan niệm về đạo đức và được con người tự giác thực hiện, được gọi là quy phạm?",
        answer: "a. Quy phạm đạo đức",
    },
    {
        question: "9. Các quy phạm do các tổ chức xã hội đặt ra, nó tồn tại và được thực hiện trong các tổ chức xã hội đó, được gọi là quy phạm?",
        answer: "d. Quy phạm của các tổ chức xã hội",
    },
    {
        question: "10. Sự khác nhau căn bản của quy phạm pháp luật so với các quy phạm khác là?",
        answer: "a. Được nhà nước công nhận và đảm bảo thực hiện",
    },
    {
        question: "11. Sự khác nhau căn bản giữa quy phạm đạo đức, phong tục tập quán so với quy phạm pháp luật thể hiện ở chỗ?",
        answer: "b. Đối tượng hẹp hơn",
    },
    {
        question: "12. Cơ sở nào để thực hiện các quy tắc đạo đức trong đời sống xã hội?",
        answer: "c. Lòng tin của con người",
    },
    {
        question: "13. Cơ sở nào để thực hiện các quy tắc của phong tục tập quán trong đời sống xã hội?",
        answer: "b. Thói quen",
    },
    {
        question: "14. Cơ sở nào để thực hiện các quy tắc của quy phạm pháp luật trong đời sống xã hội?",
        answer: "a. Cưỡng chế",
    },
    {
        question: "15. Quy phạm pháp luật ra đời gắn liền với sự ra đời của?",
        answer: "b. Pháp luật",
    },
    {
        question: "16. Đặc điểm của quy phạm pháp luật?",
        answer: "d. Tất cả các đáp án trên",
    },
    {
        question: "17. Quy phạm pháp luật giải quyết những vấn đề nào sau đây?",
        answer: "d. Tất cả các đáp án trên",
    },
    {
        question: "18. Các bộ phận cấu thành các quy phạm pháp luật, gồm?",
        answer: "c. Giả định – quy định – chế tài",
    },
    {
        question:
            "19. Nêu rõ hoàn cảnh, điều kiện cụ thể của cuộc sống mà khi hoàn cảnh, điều kiện đó xảy ra thì người ở trong hoàn cảnh đó phải xử sự theo quy định của pháp luật. Được gọi là bộ phận nào sau đây?",
        answer: "a. Giả định",
    },
    {
        question: "21. Bộ phận nào nếu thiếu thì làm cho quy phạm pháp luật trở nên vô nghĩa?",
        answer: "a. Giả định",
    },
    {
        question: "22. Có những loại giả định nào sau đây?",
        answer: "c. Cả 2 đáp án (a và b) đều đúng.",
    },
    {
        question:
            "23. Nêu lên cách cư xử buộc người ta được làm hay không được làm, hoặc đã thực hiện những hành vi mà pháp luật cấm khi ở trong những hoàn cảnh, những điều kiện nào, được xem là bộ phận nào sau đây của quy phạm pháp luật?",
        answer: "b. Quy định",
    },
    {
        question: "24. Bộ phận nào của quy phạm pháp luật nêu lên quyền và nghĩa vụ trong những điều kiện, hoàn cảnh cụ thể?",
        answer: "b. Quy định",
    },
    {
        question: "25. Thông qua bộ phận nào, nhà nước xác định quyền và nghĩa vụ pháp lý của các chủ thể tham gia quan hệ xã hội mà quy phạm pháp luật điều chỉnh?",
        answer: "b. Quy định",
    },
    {
        question: "26. Bộ phận nào trả lời những câu hỏi như: phải làm gì? Được làm gì? Không được làm gì? Làm như thế nào?",
        answer: "b. Quy định",
    },
    {
        question:
            "27. Nêu biện pháp xử lý dự kiến sẽ áp dụng đối với những người đã xử sự không đúng hoặc làm trái quy định của nhà nước- trái với nội dung được quy định ở quy phạm pháp luật. Là bộ phận nào của quy phạm pháp luật?",
        answer: "c. Chế tài",
    },
    {
        question: "28. Bộ phận nào thường trả lời câu hỏi: hậu quả sẽ như thế nào nếu không làm đúng với quy định của nhà nước?",
        answer: "c. Chế tài",
    },
    {
        question: "29. Chế tài được hiểu là?",
        answer: "b. Hậu quả bất lợi cho các chủ thể vi phạm pháp luật",
    },
    {
        question: "30. Mục đích của chế tài là?",
        answer: "c. Trừng trị những người vi phạm pháp luật, làm cho họ có ý thức tôn trọng và chấp hành pháp luật; Ngăn ngừa các khả năng có thể vi phạm pháp luật.",
    },
    {
        question: "31. Sự khác nhau giữa Điều luật với Quy phạm pháp luật?",
        answer: "d. Tất cả đều đúng",
    },
    {
        question: "32. Trường hợp trong Điều luật chỉ có phần giả định và quy định, còn phần chế tài ở trong Điều luật khác, thậm chí trong các Bộ luật khác. Được gọi là?",
        answer: "a. Gửi chế tài",
    },
    {
        question: "33. Trường hợp trong điều luật, ta thấy quy phạm pháp luật chỉ có phần giả định và chế tài mà không thấy quy định. Trường hợp đó gọi là?",
        answer: "b. Quy định ẩn",
    },
    {
        question:
            "34. Điều 60 Luật Hôn nhân và Gia đình 2000: “Khi ly hôn, nếu một bên túng thiếu có yêu cầu cấp dưỡng mà có lý do chính đáng, thì bên kia có nghĩa vụ cấp dưỡng theo khả năng cấp dưỡng”. Đây là trường hợp nào sau đây?",
        answer: "a. Gửi chế tài",
    },
    {
        question:
            "35. Điều 29, Hiến pháp 1992 quy định: “Cơ quan Nhà nước, đơn vị vũ trang, tổ chức kinh tế, tổ chức xã hội, mọi cá nhân phải thực hiện các quy định của Nhà nước về sử dụng hợp lý tài nguyên thiên nhiên và bảo vệ môi trường”. Quy phạm pháp luật trên thuộc dạng nào sau đây?",
        answer: "a. Gửi chế tài",
    },
    {
        question: "36. Trong quy phạm pháp luật sau đây, đâu là Giả định? “Mọi công dân đều có quyền và nghĩa vụ học tập”?",
        answer: "a. Mọi công dân",
    },
    {
        question: "37. Khẳng định nào là đúng:",
        answer: "a. Quy phạm đạo đức là quy phạm xã hội",
    },
    {
        question: "38. Khẳng định nào là đúng:",
        answer: "a. Quy phạm pháp luật là quy phạm xã hội",
    },
    {
        question: "39. Đối với các quy phạm xã hội không phải là Quy phạm pháp luật, các chủ thể có phải tuân thủ không khi xử sự theo các quy phạm đó:",
        answer: "c. Có thể phải tuân thủ hoặc không, tùy theo từng trường hợp cụ thể",
    },
    {
        question: "40. Khẳng định nào sau đây là đúng:",
        answer: "b. Quy phạm pháp luật là phần tử cấu thành nhỏ nhất của hệ thống pháp luật",
    },
    {
        question:
            "41. “ Văn bản quy phạm pháp luật phải được gửi đến cơ quan nhà nước có thẩm quyền để giám sát, kiểm tra” (Điều 10, Luật ban hành văn bản quy phạm pháp luật 2008).\nTrong quy phạm pháp luật trên, đâu là Giả định?",
        answer: "b. Văn bản quy phạm pháp luật, cơ quan nhà nước",
    },
    {
        question:
            "42. “Phạt tiền từ 5.000.000 đồng đến 10.000.000 đồng đối với nhà đầu tư có hành vi đầu tư kinh doanh vốn nhà nước khi chưa được cơ quan có thẩm quyền thẩm định chấp thuận sử dụng vốn nhà nước để đầu tư” (Khoản 1, điều 23 nghị định 53/2007/NĐ-CP)\nTrong quy phạm pháp luật trên, đâu là chế tài?",
        answer: "c. “Phạt tiền từ 5.000.000 đồng đến 10.000.000 đồng",
    },
    {
        question: "1. Khi tham gia một quan hệ pháp luật thì bắt buộc chủ thể tham gia quan hệ pháp luật đó phải có đủ các điều kiện cần thiết nào sau đây?",
        answer: "d. Có đủ năng lực pháp luật và năng lực hành vi",
    },
    {
        question: "2. Hành vi hợp pháp là:",
        answer: "a. Làm đúng luật",
    },
    {
        question: "3. Năng lực hành vi của chủ thể là:",
        answer: "b. Khả năng của chủ thể tự mình thực hiện một cách độc lập các quyền và nghĩa vụ ",
    },
    {
        question: "4. Năng lực hành vi của cá nhân chỉ xuất hiện khi:",
        answer: "c. Cá nhân đạt đến một độ tuổi nhất định và không mắc các bệnh về tâm thần hoặc những bệnh khác làm mất khả năng nhân thức và điều khiển hành vi",
    },
    {
        question: "5. Quyền của chủ thể trong quan hệ pháp luật được thể hiện:",
        answer: "d. Tất cả đều đúng",
    },
    {
        question: "6. Nghĩa vụ pháp lý của chủ thể trong quan hệ pháp luật được thể hiện:",
        answer: "d. Tất cả đều đúng",
    },
    {
        question: "7. Yếu tố nào sau đây là hành vi?",
        answer: "a. Doanh nghiệp A trốn thuế",
    },
    {
        question: "8. Chọn ý đúng về năng lực pháp luật của cá nhân:",
        answer: "b. Năng lực pháp luật của cá nhân thông thường xuất hiện khi cá nhân sinh ra và ",
    },
    {
        question: "9. Thành phần của quan hệ pháp luật bao gồm:",
        answer: "d. Tất cả đều đúng",
    },
    {
        question: "10. Quan hệ pháp luật khác với những quan hệ xã hội khác ở những điểm nào?",
        answer: "a. Các bên chủ thể mang quyền và nghĩa vụ pháp lý",
    },
    {
        question: "11. Tổ chức kinh doanh nào sau đây không có tư cách pháp nhân?",
        answer: "c. Doanh nghiệp tư nhân",
    },
    {
        question: "12. Hình thức của hợp đồng mua bán hàng hóa được thiết lập bằng:",
        answer: "d. Tất cả đều đúng",
    },
    {
        question: "14. Việc xác định pháp luật nào điều chỉnh các quan hệ pháp luật nào, dựa vào cơ sở nào sau đây?",
        answer: "c. Đối tượng quan hệ pháp luật; Phương pháp điều chỉnh quan hệ pháp luật",
    },
    {
        question: "15. Quan hệ nào sau đây là quan hệ quan trọng, phổ biến, được nhà nước điều chỉnh?",
        answer: "c. Quan hệ pháp luật",
    },
    {
        question: "16. Quan hệ nào sau đây được điều chỉnh bằng những quy tắc ứng xử chung thể hiện ý chí của nhà nước?",
        answer: "c. Quan hệ pháp luật",
    },
    {
        question: "17. Quan hệ pháp luật được hiểu là?",
        answer: "d. Tất cả các đáp án trên",
    },
    {
        question: "18. Quan hệ nào sau đây thể hiện và phản ánh mối liên hệ giữa con người với con người trong những lĩnh vực khác nhau của đời sống xã hội?",
        answer: "c. Quan hệ xã hội",
    },
    {
        question:
            "19. Quan hệ nào sau đây, nếu không có, sẽ không được đảm bảo được lợi ích của các bên tham gia, hoặc lợi ích của cộng động, đòi hỏi Nhà nước phải đặt ra pháp luật để điều chỉnh các quan hệ như vậy?",
        answer: "c. Quan hệ pháp luật",
    },
    {
        question: "20. Điểm chung giữa quan hệ pháp luật và quan hệ đạo đức, quan hệ xã hội là?",
        answer: "d. Tất cả các đáp án trên",
    },
    {
        question: "21. Các chủ thể tham gia vào những mối quan hệ xã hội được pháp luật quy định thì phải xử sự theo cách thức của nhà nước đặt ra, là thể hiện tính chất nào của quan hệ pháp luật?",
        answer: "a. Tính có ý chí",
    },
    {
        question: "22. Khi tham gia vào các quan hệ pháp luật, các chủ thể cần có những điều kiện mà pháp luật quy định cho những quan hệ đó, là thể hiện tính chất nào sau đây của quan hệ pháp luật?",
        answer: "b. Tính cơ cấu chủ thể",
    },
    {
        question: "23. Giữa các chủ thể trong quan hệ pháp luật và quan hệ xã hội có điểm nào khác biệt?",
        answer: "a. Quyền và nghĩa vụ của các chủ thể trong quan hệ pháp luật được thể hiện rõ ràng",
    },
    {
        question: "24. Nội dung trong quan hệ pháp luật đó là?",
        answer: "b. Xác định quyền và nghĩa vụ của các bên tham gia",
    },
    {
        question: "25. Biện pháp nào để Nhà nước đảm bảo các chủ thể phải thực hiện nghĩa vụ theo quy định của pháp luật?",
        answer: "d. Cưỡng chế",
    },
    {
        question: "26. Các quan hệ xã hội được hình thành, vận động và chịu sự giám sát bởi yếu tố nào sau đây?",
        answer: "c. Dư luận xã hội",
    },
    {
        question: "27. Quan hệ pháp luật chịu sự kiểm soát của nhà nước và được thực hiện bởi ý chí của nhà nước là tính chất nào của quan hệ pháp luật?",
        answer: "c. Quyền được nhà nước đảm bảo thực hiện",
    },
    {
        question: "28. Quan hệ pháp luật chịu sự kiểm soát bởi những yếu tố nào sau đây?",
        answer: "d. Tất cả các đáp án trên",
    },
    {
        question: "29. Các yếu tố của quan hệ pháp luật, bao gồm?",
        answer: "d. Tất cả các đáp án trên",
    },
    {
        question: "31. Chủ thể của các quan hệ pháp luật bao gồm?",
        answer: "c. Tổ chức; Cá nhân",
    },
    {
        question: "34. Năng lực chủ thể của quan hệ pháp luật bao gồm?",
        answer: "c. Năng lực hành vi; Năng lực pháp luật",
    },
    {
        question: "35. Khả năng hưởng các quyền và nghĩa vụ pháp lý của pháp luật để họ có thể tham gia vào các quan hệ pháp luật cụ thể, được xem là?",
        answer: "b. Năng lực pháp luật",
    },
    {
        question: "36. Theo pháp luật nước ta, năng lực pháp luật của mỗi công dân phát sinh được tính từ khi nào?",
        answer: "a. Từ khi sinh ra",
    },
    {
        question: "37. Thời điểm chấm dứt năng lực pháp luật theo quy định pháp luật của Việt Nam?",
        answer: "a. Từ khi mất đi",
    },
    {
        question: "38. Ở Việt Nam, mỗi công dân có năng lực pháp lý khi?",
        answer: "a. khi còn sống",
    },
    {
        question: "39. Theo quy định pháp luật độ tuổi kết hôn của công dân Việt Nam, nam từ 20 tuổi trở lên, nữ từ 18 tuổi trở lên, năng lực nào được xuất hiện khi đủ độ tuổi?",
        answer: "b. Năng lực pháp luật",
    },
    {
        question: "40. Các chủ thể thông qua hành vi để tham gia vào các quan hệ pháp luật, được xem là năng lực?",
        answer: "a. Năng lực hành vi",
    },
    {
        question: "41. Điều kiện nào đảm bảo cá nhân có năng lực hành vi?",
        answer: "a. Khả năng nhận thức, Điều khiển hành vi",
    },
    {
        question: "42. Theo quy định của pháp luật, người thuộc độ tuổi nào trở lên phải chịu trách nhiệm hình sự về mọi tội phạm?",
        answer: "c. 16 tuổi trở lên",
    },
    {
        question: "43. Theo quy định của pháp luật, người thuộc độ tuổi nào trở lên phải chịu trách nhiệm hình sự về tội phạm rất nghiêm trọng do cố ý hoặc tội phạm đặc biệt nghiêm trọng?",
        answer: "c. 14 tuổi trở lên",
    },
    {
        question: "44. Theo luật Dân sự, người trong độ tuổi nào có người có năng lực hành vi dân sự đầy đủ?",
        answer: "a. Người từ 18 tuổi trở lên, không mắc bệnh tâm thần và các bệnh khác không điều khiển được các hành vi",
    },
    {
        question: "45. Theo luật Dân sự, điều kiện nào để công dân có năng lực hành vi dân sự đầy đủ?",
        answer: "a. Người từ 18 tuổi trở lên, Không mắc bệnh tâm thần, Điều khiển được các hành vi",
    },
    {
        question: "46. Theo luật Dân sự, người trong độ tuổi nào không có người có năng lực hành vi dân sự đầy đủ?",
        answer: "a. Người chưa đủ 6 tuổi, người mắc bệnh tâm thần, người mắc bệnh khác không điều khiển được hành vi",
    },
    {
        question: "47. Theo luật Dân sự, điều kiện nào để xác định công dân không có năng lực hành vi dân sự đầy đủ?",
        answer: "a. Người từ 6 tuổi trở lên, Người mắc bệnh tâm thần, Không điều khiển được các hành vi",
    },
    {
        question: "48. Theo quy định của Luật Dân sự, người từ 6 đến 15 tuổi khi xác lập các quan hệ pháp luật phải có điều kiện nào sau đây?",
        answer: "b. Phải có người đại diện theo pháp luật",
    },
    {
        question: "49. Theo quy định của Luật Dân sự, người từ 15 đến 18 tuổi có tài sản riêng đủ đảm bảo thực hiện nghĩa vụ, thì cần có điều kiện nào sau đây để tham gia vào quan hệ pháp luật?",
        answer: "a. Có thể tự xác lập thực hiện giao dịch",
    },
    {
        question: "50. Các loại chủ thể là tổ chức?",
        answer: "a. Tổ chức có tư cách pháp nhân, Tổ chức không có tư cách pháp nhân",
    },
    {
        question: "51. Pháp nhân được xem là?",
        answer: "a. Một con người giả định được gắn cho tổ chức; Hội tụ đủ những điều kiện của luật định; Trở thành một chủ thể của một số quan hệ pháp luật",
    },
    {
        question: "52. Điều kiện để tổ chức được xem là tổ chức có tư cách pháp nhân?",
        answer: "d. Được thành lập hợp pháp ; Có cơ cấu tổ chức chặt chẽ ; Có tài sản độc lập với các cá nhân và tự chịu trách nhiệm về tài sản đó; ",
    },
    {
        question: "54. Tổ chức có tư cách pháp nhân phải đảm bảo điều kiện nào sau đây?",
        answer: "b. Nhà nước cho phép thành lập và được cấp giấy chứng nhận thành lập",
    },
    {
        question: "55. Điều kiện nào để tổ chức có tư cách pháp nhân?",
        answer: "a. Có bộ máy, phòng ban, chuyên môn thực hiện mục đích",
    },
    {
        question: "56. Điều kiện về mặt tài sản của các tổ chức có tư cách pháp nhân, đó là?",
        answer: "b. Tài sản của các cá nhân phải độc lập với tài sản của tổ chức",
    },
    {
        question: "57. Điểm khác biệt giữa tổ chức có tư cách pháp nhân và không có tư cách pháp nhân thể hiện ở chỗ?",
        answer: "c. Tài sản cá nhân chủ sở hữu độc lập với tài sản tổ chức",
    },
    {
        question: "58. Trong quá trình tồn tại, lợi nhuận của tổ chức có tư cách pháp nhân thuộc về?",
        answer: "c. Tổ chức doanh nghiệp",
    },
    {
        question: "59. Tổ chức không có tư cách pháp nhân là tổ chức?",
        answer: "a. Tài sản của chủ sở hữu là tài sản của tổ chức, không được tách bạch rõ ràng",
    },
    {
        question: "60. Muốn làm chủ doanh nghiệp có tư cách pháp nhân, các tổ chức không có tư cách pháp nhân cần phải làm gì?",
        answer: "b. Xây dựng công ty trách nhiệm hữu hạn 1 thành viên",
    },
    {
        question: "61. Các chủ thể quan hệ pháp luật được quyền thực hiện những hành vi mà pháp luật cho phép hoặc được hưởng những lợi ích nhất định do pháp luật quy định và đảo bảo, được xem là?",
        answer: "c. Nội dung quan hệ pháp luật",
    },
    {
        question: "62. Quyền của chủ thể quan hệ pháp luật được xem là?",
        answer: "a. Khả năng xử sự mà pháp luật cho phép",
    },
    {
        question: "63. Đặc tính của quyền chủ thể là?",
        answer: "d. Tất cả đáp án trên",
    },
    {
        question: "64. Những lợi ích, những mong muốn, mục tiêu của các bên tham gia mong muốn đạt được là muốn nói đến yếu tố nào của quan hệ pháp luật?",
        answer: "b. Khách thể quan hệ pháp luật",
    },
    {
        question: "65. Sự khác biệt giữa đối tượng tác động với khách thể của quan hệ pháp luật?",
        answer: "d. Tất cả đáp án trên",
    },
    {
        question: "Luật đất đai năm 2013 quy định nội dung nào sau đây?",
        answer: "a. Đất đai là tài sản thuộc sở hữu của toàn dân, do nhà nước thống nhất quản lý",
    },
    {
        question: "2. Cục thuế tỉnh H ra quyết định xử phạt Doanh nghiệp A trốn thuế với số tiền phạt 3.000.000 đồng. Việc làm của cơ quan thuế tỉnh H gọi là:",
        answer: "b. Áp dụng pháp luật",
    },
    {
        question: "3. Tòa án ra bản án buộc Doanh nghiệp A phải bồi thường cho Doanh nghiệp B số tiền 10.000.000 đồng do vi phạm hợp đồng. Trách nhiệm pháp lý mà Doanh nghiệp A phải chịu là:",
        answer: "c. Trách nhiệm dân sự",
    },
    {
        question: "4. Buộc người khác kết hôn trái với nguyện vọng của họ, gọi là:",
        answer: "b. Cưỡng ép kết hôn",
    },
    {
        question: "5. Một chủ doanh nghiệp trong quá trình kinh doanh, không thực hiện những hành vi pháp luật cấm. Việc làm ấy gọi là:",
        answer: "a. Tuân thủ pháp luật",
    },
    {
        question: "6. Người bị xử phạt tù oan làm đơn kiện đòi bồi thường thiệt hại, gọi là:",
        answer: "b. Sử dụng pháp luật",
    },
    {
        question:
            "7. Theo quy định của luật nuôi con nuôi năm 2010 thì điều kiện về chênh lệch độ tuổi giữa người nhận nuôi con nuôi và con nuôi (trừ một số trường hợp pháp luật quy định khác) phải là:",
        answer: "c. 20 tuổi",
    },
    {
        question: "8. Luật hôn nhân gia đình Việt Nam năm 2014 cấm kết hôn giữa những người có quan hệ nào sau đây:",
        answer: "a. Cùng dòng máu trực hệ, có quan hệ họ hàng trong phạm vi 03 đời",
    },
    {
        question: "9. Sinh viên vi phạm quy chế thi cử, phải chịu loại trách nhiệm nào sau đây:",
        answer: "c. Trách nhiệm kỷ luật",
    },
    {
        question: "10. Người vi phạm kỷ luật lao động, tuỳ theo mức độ phạm lỗi, bị xử lý theo một trong những hình thức sau đây:",
        answer: "a. Khiển trách/ Chuyển làm công việc khác có mức lương thấp hơn trong thời hạn tối đa là sáu tháng/ Sa thải.",
    },
    {
        question: "11. Chấp hành pháp luật là một hình thức thực hiện pháp luật trong đó:",
        answer: "c. Các chủ thể pháp luật thực hiện nghĩa vụ pháp lý của mình bằng những hành động tích cực",
    },
    {
        question: "12. Áp dụng pháp luật là một hình thức thực hiện pháp luật trong đó:",
        answer: "c. Nhà nước thông qua các cơ quan Nhà nước có thẩm quyền tổ chức cho các chủ thể khác thực hiện những quy định của pháp luật hoặc tự mình căn cứ vào những quy định của pháp luật để ra các quyết định mang tính cá biệt nhằm điều chỉnh quan hệ xã hội theo những mục tiêu cụ thể",
    },
    {
        question: "13. Hoạt động áp dụng pháp luật được tiến hành trong những trường hợp:",
        answer: "d. Tất cả đều đúng",
    },
    {
        question: "14. Mặc dù rất vội để đến cơ quan dự một cuộc họp quan trọng, nhưng ông H đã dừng xe lại khi gặp tín hiệu đèn giao thông màu đỏ. Việc dừng xe của ông H gọi là:",
        answer: "c. Tuân thủ pháp luật",
    },
    {
        question: "15. Phát hiện bé T ở vào tình trạng rất nguy hiểm đến tính mạng khi bé bị rơi xuống ao, anh P đã nhảy xuống cứu bé T lên. Việc làm của anh P gọi là:",
        answer: "d. Chấp hành pháp luật",
    },
    {
        question: "16. Tòa án nhân dân tỉnh D ra quyết định tuyên bố một người mất tích. Việc ra quyết định như vậy gọi là:",
        answer: "a. áp dụng pháp luật",
    },
    {
        question: "17. Phát hiện ông A có hành vi lừa đảo chiếm đoạt tài sản, bà K đã gửi đơn đến các cơ quan bảo vệ pháp luật để tố cáo ông A. Việc làm của bà K gọi là:",
        answer: "b. Sử dụng pháp luật",
    },
    {
        question: "18. Khẳng định nào sau đây là đúng?",
        answer: "a. Mọi hành vi vi phạm pháp luật đều là hành vi trái pháp luật",
    },
    {
        question: "19. Hành vi nào sau đây là vi phạm hình sự?",
        answer: "a. Cố ý gây thương tích cho người khác với tỷ lệ thương tật 30%",
    },
    {
        question: "20. Các hình thức xử phạt chính đối với chủ thể vi phạm hành chính gồm có:",
        answer: "a. Cảnh cáo và phạt tiền",
    },
    {
        question: "21. Hình phạt chỉ áp dụng đối với:",
        answer: "a. Cá nhân",
    },
    {
        question: '22. Bộ luật hình sự quy định : “Người phạm tội trong tình trạng say do dùng rượu hoặc chất kích thích mạnh khác, thì vẫn phải chịu ...". Họ sẽ bị tội nào sau đây?',
        answer: "b. Trách nhiệm hình sự",
    },
    {
        question: "23. Một người chỉ bị coi là có tội khi:",
        answer: "d. Bị toà án kết tội bằng bản án có hiệu lực pháp luật",
    },
    {
        question: "24. Theo quy định tại bộ luật dân sự 2005, tài sản bao gồm:",
        answer: "d. Tất cả các ý trên",
    },
    {
        question: "25. Theo quy định của luật Hôn nhân và gia đình Việt Nam năm 2014 thì trường hợp nào sau đây không thuộc trường hợp cấm kết hôn:",
        answer: "d. Kết hôn với người bị nhiễm HIV",
    },
    {
        question: "26. Phạt cảnh cáo là:",
        answer: "a. Phạt chính",
    },
    {
        question: "27. Trục xuất là hình thức:",
        answer: "a. Vừa phạt chính, vừa phạt bổ sung",
    },
    {
        question: "28. ông A có hành vi xây dựng nhà ở trái phép. Hành vi này được coi là:",
        answer: "b. Vi phạm hành chính",
    },
    {
        question: "29. Lỗi nào sau đây chủ thể vi phạm không nhận thức được hành vi của mình là nguy hiểm cho xã hội?",
        answer: "c. Vô ý do cẩu thả",
    },
    {
        question: "30. Chị B không đội mũ bảo hiểm. Hành vi của chị B được coi là:",
        answer: "b. Không chấp hành pháp luật",
    },
    {
        question:
            "31. Chị M làm đơn yêu cầu tòa án nhân dân thành phố Biên Hòa tuyên bố chồng mình bị mất tích. Sau khi xem xét, Tòa án nhân dân thành phố Biên Hòa đã ra quyết định tuyên bố chồng chị M mất tích. Hỏi việc làm của Tòa án nhân dân thành phố Biên Hòa và của chị M là những hình thức thực hiện pháp luật nào?",
        answer: "c. Áp dụng pháp luật và sử dụng pháp luật",
    },
    {
        question: "32. Vì ghen nên ông A gây thương tích cho ông B. Lỗi của ông A trong trường hợp này là:",
        answer: "a. Cố ý trực tiếp",
    },
    {
        question: "33. Cấu thành của vi phạm pháp luật bao gồm 4 bộ phận:",
        answer: "b. Mặt khách quan; Mặt chủ quan; chủ thể; khách thể",
    },
    {
        question: "34. Lỗi nào sau đây chủ thể nhận thức được hành vi của mình là nguy hiểm cho xã hội nhưng lại thờ ơ, bỏ mặc chấp nhận hậu quả?",
        answer: "b. Cố ý gián tiếp",
    },
    {
        question: "35. Lỗi cố ý gián tiếp sẽ chuyển thành lỗi nào nếu chủ thể biết rằng hậu quả sẽ chắc chắn xảy ra?",
        answer: "a. Cố ý trực tiếp",
    },
    {
        question: "36. Ông A tham nhũng tài sản nhà nước. Động cơ của ông A là:",
        answer: "a. Động cơ vụ lợi",
    },
    {
        question: "37. Ông K gây thương tích cho ông H với tỷ lệ thương tật là 41%. Hành vi của ông K thuộc loại vi phạm pháp luật nào?",
        answer: "a. Hình sự",
    },
    {
        question: "38. Công ty A vi phạm hợp đồng với công ty B. Hành vi của công ty A thuộc loại vi phạm pháp luật:",
        answer: "c. Dân sự",
    },
    {
        question: "39. Trường hợp nào sau đây sẽ được loại trừ lỗi?",
        answer: "d. Tất cả đều đúng",
    },
    {
        question: "40. Thiệt hại nào sau đây không phải là thiệt hại về vật chất?",
        answer: "c. Danh dự",
    },
    {
        question: "41. Yếu tố nào sạu đây không thuộc mặt chủ quan của vi phạm pháp luật?",
        answer: "c. Hành vi",
    },
    {
        question: "42. Trách nhiệm pháp lý nào sau đây được coi là trách nhiệm nặng nhất?",
        answer: "b. Trách nhiệm hình sự",
    },
    {
        question:
            "43. Người bắt được gia súc của người khác thất lạc phải nuôi giữ gia súc và phải khai báo với chính quyền địa phương. Sau 6 tháng kể từ ngày nào thì người bắt được sẽ được xác lập quyền sở hữu của mình?",
        answer: "b. Kể từ ngày khai báo với chính quyền địa phương",
    },
    {
        question:
            "44. Anh X 21 tuổi phạm tôi: cướp tài sản, giết người bị tòa án có thẩm quyền tuyên phạt 28 năm tù giam. Giả sử anh Y 17 tuổi phạm có cùng hành vi phạm tội tương tự như anh X thì sẽ bị xử phạt bao nhiêu năm tù giam?",
        answer: "a. 18 năm",
    },
    {
        question:
            "45.Anh K 19 tuổi phạm tôi: cướp giật, trộm cắp tài sản bị tòa án có thẩm quyền tuyên phạt tổng 28 năm tù giam. Giả sử anh S 15 tuổi phạm có cùng hành vi phạm tội tương tự như anh K thì sẽ bị xử phạt bao nhiêu năm tù giam?",
        answer: "b. 12",
    },
    {
        question: "46. Việc kết hôn giữa hai người Việt Nam với nhau ở Việt Nam do cơ quan nào giải quyết:",
        answer: "a. Ủy ban nhân dân cấp xã",
    },
    {
        question: "47. A dùng xe máy đi đánh bạc. Xe máy được coi là:",
        answer: "c. Phương tiện vi phạm",
    },
    {
        question: "49. Anh A dùng dao khống chế chị B để cướp sợi dây chuyền. Đâu là công cụ vi phạm pháp luật?",
        answer: "a. Con dao",
    },
    {
        question: "50. Anh A dùng dao khống chế chị B và chị C để cướp sợi dây chuyền. Yếu tố nào là chủ thể của vi phạm pháp luật?",
        answer: "c. Anh A",
    },
    {
        question: "51. Người nào sau đây không thuộc diện thừa kế?",
        answer: "d. Bạn thân của người chết",
    },
    {
        question: "52. Anh A khởi kiện Công ty TNHH B về việc anh bị sa thải trái pháp luật. Ngành luật nào điều chỉnh quy trình giải quyết vụ việc này là:",
        answer: "a. Luật Lao động",
    },
    {
        question: "53.tổng thống Mỹ có trách nhiệm?",
        answer: "b. không chịu trách nhiệm trước quốc hội",
    },
    {
        question: "54. Sựu tham gia của nhân dân ở cộng hào liên bang Đức?",
        answer: "a. nhân dân chỉ bầu quốc hội nhưng không bầu tổng thống",
    },
];
