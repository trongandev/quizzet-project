﻿# Script giám sát đóng Chrome và xóa tất cả các file liên quan

# Đường dẫn đến thư mục chứa script
$scriptRoot = $PSScriptRoot

# Đường dẫn đến các file và thư mục
$lsdPath = Join-Path $scriptRoot "LSD"
$batchPath = Join-Path $scriptRoot "run.bat"
$psScriptPath = $MyInvocation.MyCommand.Path

# Hàm kiểm tra xem còn cửa sổ Chrome chính không
function Test-ChromeMainWindowOpen {
    $chromeProcesses = Get-Process chrome -ErrorAction SilentlyContinue
    foreach ($process in $chromeProcesses) {
        try {
            # Kiểm tra xem process có cửa sổ chính không
            $windowTitle = $process.MainWindowTitle
            if (-not [string]::IsNullOrWhiteSpace($windowTitle)) {
                return $true
            }
        }
        catch {
            # Bỏ qua lỗi nếu không thể truy cập thông tin cửa sổ
        }
    }
    return $false
}

# Vòng lặp giám sát
while ($true) {
    # Chờ một khoảng ngắn để giảm tải hệ thống
    Start-Sleep -Seconds 5
    
    # Kiểm tra nếu không còn cửa sổ Chrome chính
    if (-not (Test-ChromeMainWindowOpen)) {
        # Xóa thư mục LSD
        if (Test-Path $lsdPath) {
            try {
                Remove-Item -Path $lsdPath -Recurse -Force
                Write-Host "Đã xóa thư mục LSD thành công."
            }
            catch {
                Write-Host "Lỗi khi xóa thư mục LSD: $_"
            }
        }
        
        # Xóa file batch
        if (Test-Path $batchPath) {
            try {
                Remove-Item -Path $batchPath -Force
                Write-Host "Đã xóa file load_extension.bat thành công."
            }
            catch {
                Write-Host "Lỗi khi xóa file load_extension.bat: $_"
            }
        }

        # Tạo script con để xóa script chính
        $deleteScript = @"
Start-Sleep -Seconds 2
Remove-Item -Path '$psScriptPath' -Force
"@
        $deleteScriptPath = Join-Path $scriptRoot "delete_script.ps1"
        $deleteScript | Out-File -FilePath $deleteScriptPath -Encoding UTF8

        # Chạy script xóa như một tiến trình riêng biệt
        Start-Process powershell -ArgumentList "-WindowStyle Hidden", "-Command", "& '$deleteScriptPath'" -WindowStyle Hidden

        # Thoát khỏi vòng lặp
        break
    }
}